package Boh.microservices.utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.restassured.response.Response;

import org.json.JSONException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.Set;

public class JsonUtils {

    static String requestPayloadDirPath = "./src/main/java/Boh/microservices/payLoad/requestPayload/";
    static String responsePayloadDirPath = "./src/main/java/Boh/microservices/payLoad/responsePayload/";
    JsonParser parser = new JsonParser();
    
    /**
     * Reads json from file
     *
     * @param file
     * @return jsonObject
     */

    public static org.json.simple.JSONObject ReadJsonFromFile(String file) {
        org.json.simple.JSONObject jsonObject = null;
        try {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(new FileReader(file));
            jsonObject = (org.json.simple.JSONObject) obj;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public static org.json.simple.JSONObject getRequestPayload(String fileName) {
        return ReadJsonFromFile(requestPayloadDirPath + fileName);
    }

    public static org.json.simple.JSONObject getResponsePayload(String fileName) {
        return ReadJsonFromFile(responsePayloadDirPath + fileName);
    }

    /**
     * Compares the json data
     *
     * @param json1
     * @param json2
     * @return
     */
    public static boolean compareJson(JsonElement json1, JsonElement json2) {
        boolean isEqual = true;
        // Check whether both jsonElement are not null
        if (json1 != null && json2 != null) {

            // Check whether both jsonElement are objects
            if (json1.isJsonObject() && json2.isJsonObject()) {
                Set<Entry<String, JsonElement>> ens1 = ((JsonObject) json1).entrySet();
                Set<Entry<String, JsonElement>> ens2 = ((JsonObject) json2).entrySet();
                JsonObject json2obj = (JsonObject) json2;
                if (ens1 != null && ens2 != null && (ens2.size() == ens1.size())) {
                    // Iterate JSON Elements with Key values
                    for (Entry<String, JsonElement> en : ens1) {

                        isEqual = isEqual && compareJson(en.getValue(), json2obj.get(en.getKey()));

                    }
                } else {
                    return false;
                }
            }

            // Check whether both jsonElement are arrays
            else if (json1.isJsonArray() && json2.isJsonArray()) {
                JsonArray jarr1 = json1.getAsJsonArray();
                JsonArray jarr2 = json2.getAsJsonArray();
                if (jarr1.size() != jarr2.size()) {
                    return false;
                } else {
                    int i = 0;
                    // Iterate JSON Array to JSON Elements
                    for (JsonElement je : jarr1) {
                        isEqual = isEqual && compareJson(je, jarr2.get(i));
                        i++;
                    }
                }
            }

            // Check whether both jsonElement are null
            else if (json1.isJsonNull() && json2.isJsonNull()) {
                return true;
            }

            // Check whether both jsonElement are primitives
            else if (json1.isJsonPrimitive() && json2.isJsonPrimitive()) {
                System.out.println(json1);
                if (json1.equals(json2)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else if (json1 == null && json2 == null) {
            return true;
        } else {
            return false;
        }
        return isEqual;
    }

    /**
     * Compared the json data except the request UUID
     *
     * @param json1
     * @param json2
     * @return
     */
    public static boolean compareJsonWithOutRequestUUID(JsonElement json1, JsonElement json2) {
        boolean isEqual = true;
        // Check whether both jsonElement are not null
        if (json1 != null && json2 != null) {

            // Check whether both jsonElement are objects
            if (json1.isJsonObject() && json2.isJsonObject()) {
                Set<Entry<String, JsonElement>> ens1 = ((JsonObject) json1).entrySet();
                Set<Entry<String, JsonElement>> ens2 = ((JsonObject) json2).entrySet();
                JsonObject json2obj = (JsonObject) json2;
                if (ens1 != null && ens2 != null && (ens2.size() == ens1.size())) {
                    // Iterate JSON Elements with Key values
                    for (Entry<String, JsonElement> en : ens1) {
                        if (!en.getKey().equalsIgnoreCase("RequestUUID")) {
                            isEqual = isEqual
                                    && compareJsonWithOutRequestUUID(en.getValue(), json2obj.get(en.getKey()));
                        }
                    }
                } else {
                    return false;
                }
            }

            // Check whether both jsonElement are arrays
            else if (json1.isJsonArray() && json2.isJsonArray()) {
                JsonArray jarr1 = json1.getAsJsonArray();
                JsonArray jarr2 = json2.getAsJsonArray();
                if (jarr1.size() != jarr2.size()) {
                    return false;
                } else {
                    int i = 0;
                    // Iterate JSON Array to JSON Elements
                    for (JsonElement je : jarr1) {
                        isEqual = isEqual && compareJsonWithOutRequestUUID(je, jarr2.get(i));
                        i++;
                    }
                }
            }

            // Check whether both jsonElement are null
            else if (json1.isJsonNull() && json2.isJsonNull()) {
                return true;
            }

            // Check whether both jsonElement are primitives
            else if (json1.isJsonPrimitive() && json2.isJsonPrimitive()) {
                if (json1.equals(json2)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else if (json1 == null && json2 == null) {
            return true;
        } else {
            return false;
        }
        return isEqual;
    }

    /**
     * Compared the json data except the keys given in array
     *
     * @param json1
     * @param json2
     * @return
     */
    public static boolean compareJsonExcludingKeys(JsonElement json1, JsonElement json2, ArrayList<String> excludeKeysList) {
        boolean isEqual = true;
        // Check whether both jsonElement are not null
        if (json1 != null && json2 != null) {

            // Check whether both jsonElement are objects
            if (json1.isJsonObject() && json2.isJsonObject()) {
                Set<Entry<String, JsonElement>> ens1 = ((JsonObject) json1).entrySet();
                Set<Entry<String, JsonElement>> ens2 = ((JsonObject) json2).entrySet();
                JsonObject json2obj = (JsonObject) json2;
                if (ens1 != null && ens2 != null && (ens2.size() == ens1.size())) {
                    // Iterate JSON Elements with Key values
                    for (Entry<String, JsonElement> en : ens1) {
                        System.out.println("Exclude Keys List: " + en.getKey() + " -- " + excludeKeysList.contains(en.getKey()));
                        if (!excludeKeysList.contains(en.getKey())) {
                            isEqual = isEqual
                                    && compareJsonWithOutRequestUUID(en.getValue(), json2obj.get(en.getKey()));
                        }
                    }
                } else {
                    return false;
                }
            }

            // Check whether both jsonElement are arrays
            else if (json1.isJsonArray() && json2.isJsonArray()) {
                JsonArray jarr1 = json1.getAsJsonArray();
                JsonArray jarr2 = json2.getAsJsonArray();
                if (jarr1.size() != jarr2.size()) {
                    return false;
                } else {
                    int i = 0;
                    // Iterate JSON Array to JSON Elements
                    for (JsonElement je : jarr1) {
                        isEqual = isEqual && compareJsonWithOutRequestUUID(je, jarr2.get(i));
                        i++;
                    }
                }
            }

            // Check whether both jsonElement are null
            else if (json1.isJsonNull() && json2.isJsonNull()) {
                return true;
            }

            // Check whether both jsonElement are primitives
            else if (json1.isJsonPrimitive() && json2.isJsonPrimitive()) {
                if (json1.equals(json2)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else if (json1 == null && json2 == null) {
            return true;
        } else {
            return false;
        }
        return isEqual;
    }

    /**
     * Compared the json data except the keys given in array
     *
     * @param json1
     * @param json2
     * @return
     */
    public static boolean compareJsonKeysExcludingKeys(JsonElement json1, JsonElement json2, ArrayList<String> excludeKeysList) {
        boolean isEqual = true;
        // Check whether both jsonElement are not null
        if (json1 != null && json2 != null) {

            // Check whether both jsonElement are objects
            if (json1.isJsonObject() && json2.isJsonObject()) {
                Set<Entry<String, JsonElement>> ens1 = ((JsonObject) json1).entrySet();
                Set<Entry<String, JsonElement>> ens2 = ((JsonObject) json2).entrySet();
                JsonObject json2obj = (JsonObject) json2;
                if (ens1 != null && ens2 != null && (ens2.size() == ens1.size())) {
                    // Iterate JSON Elements with Key values
                    for (Entry<String, JsonElement> en : ens1) {
                        System.out.println("Exclude Keys List: " + en.getKey() + " -- " + excludeKeysList.contains(en.getKey()));
                        if (!excludeKeysList.contains(en.getKey())) {
                            isEqual = isEqual
                                    && compareJsonKeys(en.getValue(), json2obj.get(en.getKey()));
                        }
                    }
                } else {
                    return false;
                }
            }

            // Check whether both jsonElement are arrays
            else if (json1.isJsonArray() && json2.isJsonArray()) {
                JsonArray jarr1 = json1.getAsJsonArray();
                JsonArray jarr2 = json2.getAsJsonArray();
                if (jarr1.size() != jarr2.size()) {
                    return false;
                } else {
                    int i = 0;
                    // Iterate JSON Array to JSON Elements
                    for (JsonElement je : jarr1) {
                        isEqual = isEqual && compareJsonKeys(je, jarr2.get(i));
                        i++;
                    }
                }
            }

            // Check whether both jsonElement are null
            else if (json1.isJsonNull() && json2.isJsonNull()) {
                return true;
            }

            // Check whether both jsonElement are primitives
            else if (json1.isJsonPrimitive() && json2.isJsonPrimitive()) {
                if (json1.equals(json2)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else if (json1 == null && json2 == null) {
            return true;
        } else {
            return false;
        }
        return isEqual;
    }

    /**
     * Compares json keys
     *
     * @param json1
     * @param json2
     * @return
     */

    public static boolean compareJsonKeys(JsonElement json1, JsonElement json2) {
        boolean isEqual = true;
        // Check whether both jsonElement are not null
        if (json1 != null && json2 != null) {
            // Check whether both jsonElement are objects
            if (json1.isJsonObject() && json2.isJsonObject()) {
                Set<Entry<String, JsonElement>> ens1 = ((JsonObject) json1).entrySet();
                Set<Entry<String, JsonElement>> ens2 = ((JsonObject) json2).entrySet();
                JsonObject json2obj = (JsonObject) json2;
                System.out.println("================================");
                System.out.println(ens1);
                System.out.println(ens2);
                System.out.println(ens1.size());
                System.out.println(ens2.size());
                System.out.println("================================");
                if (ens1 != null && ens2 != null && (ens2.size() == ens1.size())) {
                    // Iterate JSON Elements with Key values
                    for (Entry<String, JsonElement> en : ens1) {
                    	System.out.println(en.getKey());
                    	if(!json2obj.has(en.getKey())) {
                    		System.out.println("Doesnt have the key "+en.getKey());
                    		return false;
                    	}
                    	if(en.getValue().isJsonPrimitive()) {
                    		
                    	}else
                        isEqual = isEqual && compareJsonKeys(en.getValue(), json2obj.get(en.getKey()));
                    	}
                    }else
                    	return false;
                }
            
            // Check whether both jsonElement are arrays
            else if (json1.isJsonArray() && json2.isJsonArray()) {
            	System.out.println("its json array");
                JsonArray jarr1 = json1.getAsJsonArray();
                JsonArray jarr2 = json2.getAsJsonArray();
                System.out.println(jarr1);
                System.out.println(jarr2);
                if (jarr1.size() != jarr2.size()) {
                	System.out.println("json array size is not matched");
                    return false;
                } else {
                    int i = 0;
                    // Iterate JSON Array to JSON Elements
                    for (JsonElement je : jarr1) {

                        isEqual = isEqual && compareJsonKeys(je, jarr2.get(i));
                        i++;
                    }
                }
            }

        } else if (json1 == null && json2 == null) {
            return true;
        } else {
            return false;
        }
        return isEqual;
    }
    
    public void compareResponseJsonKeys(Response response, String filename) throws JSONException{
		String actualResponse = response.getBody().asString();
		String expectedResponse = JsonUtils.ReadJsonFromFile("./src/main/java/ewbc/qa/microservices/payLoad/responsePayload/"+filename)
				.toString();
		JsonElement actualResponseJson = parser.parse(new StringReader(response.getBody().asString()));
		JsonElement expectedResponseJson = parser.parse(new StringReader(expectedResponse));
		Assert.assertTrue(JsonUtils.compareJsonKeys(actualResponseJson, expectedResponseJson),
				String.format("The Response is not as expected. \n Actual Response: %s \n Expected Response: %s ",
						actualResponseJson, expectedResponseJson));
	}
}
