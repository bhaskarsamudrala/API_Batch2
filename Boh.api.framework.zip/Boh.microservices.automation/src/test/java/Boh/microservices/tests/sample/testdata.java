package Boh.microservices.tests.sample;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.model.ITest;

public class testdata {
	@Test(dataProvider ="test-data",priority = 0)
	public void test_par(String keyword) {
		
		System.out.println("Start test_first *****");
		System.out.println(keyword);
		System.out.println("ENd test_first  *****");
	}
	
	@Test(dataProvider ="test-data",priority = 0)
	public void test_sec(String keyword) {
		
		System.out.println("Start test_sec *****");
		System.out.println(keyword);
		System.out.println("ENd test_sec *****");
	}

	@DataProvider(name = "test-data")
	public Object[][] dataProvFunc() {
		System.out.println("DB provider");
		return new Object[][] { { "Lambda Test" }, { "Automation" } };
	}


}
