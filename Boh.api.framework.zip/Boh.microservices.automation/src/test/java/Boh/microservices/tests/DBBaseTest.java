package Boh.microservices.tests;

import java.util.Properties;

import com.ewb.base.BaseTest;
import com.ewb.utils.Log;
import com.ewb.utils.PropertyReader;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class DBBaseTest extends BaseTest {
	public static String propertyFile;
	public String environment = System.getProperty("environment");
	public String groups = System.getProperty("groups");
	public static Properties properties;

	public DBBaseTest() {
		//propertyFile = "./src/test/resources/environment/" + environment + "/input.properties";
		propertyFile = "./src/test/resources/environment/" + "qa" + "/input.properties";
		properties = PropertyReader.getProperties(propertyFile);
	}

	@BeforeSuite(
			alwaysRun = true
	)
	public final void mandatoryAfterSuiteAddEnvironment(ITestContext context) {
		System.out.println("in DBbasetest");
		extent.addSystemInfo("Environment", "myenvi");
		extent.addSystemInfo("Groups Executed", "groups");
	}

}
