package Boh.microservices.tests.sample;

import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotEqualsDeep;

import java.io.PrintStream;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.Properties;

import org.apache.commons.io.output.WriterOutputStream;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ewb.utils.PropertyReader;
import com.ewb.utils.RestUtil;
import com.ewb.utils.Listeners.TestListener;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.relevantcodes.extentreports.LogStatus;

import Boh.microservices.businessobjects.requestObjects.Sample.CreateCustomerRequest;
import Boh.microservices.businessobjects.requestObjects.Sample.CreateCustomerResponse;
//import ewbc.qa.microservices.businessobjects.responseObjects.BillpayAPI.AddBankAccount.AddbankAccountResponse;
//import ewbc.qa.microservices.businessobjects.responseObjects.OktaAuthenticationAPI.OktaAuthFailResponseObject;
import Boh.microservices.constants.Group;
//import ewbc.qa.microservices.tests.DBBaseTest;
import Boh.microservices.tests.DBBaseTest;
import Boh.microservices.utils.JsonUtils;
import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class myTestTest extends DBBaseTest {

	Properties properties = PropertyReader.getProperties(propertyFile);
	String baseurl = properties.getProperty("base_url");
	String customer_endpoint = properties.getProperty("customer_endpoint");

	RequestSpecification request;
	PrintStream requestCapture;
	StringWriter requestWriter;
	JsonParser parser;

	@BeforeMethod(alwaysRun = true)
	public void setUri() {

		System.out.println("baseurl"+baseurl);
		System.out.println("customer_endpoint"+customer_endpoint);
		requestWriter = new StringWriter();
		requestCapture = new PrintStream(new WriterOutputStream(requestWriter, Charset.defaultCharset()), true);

		RestUtil.setBaseURI(baseurl);
		RestUtil.setContentType(ContentType.JSON);
		request = RestAssured.given().filter(new RequestLoggingFilter(LogDetail.ALL, true, requestCapture)).log().all();
//		JsonPath response = RestAssured
//				.given()
//				    .header("Authorization", "Basic " + encodedString)
//				    .when()
//				    .get(GET_PUSH_API)
//				.then()
//				    .statusCode(401)
//				    .extract().jsonPath();.
		request.header("Content-Type", "application/json");

		parser = new JsonParser();
	}

	@Test(description = "Verify Customer Creation Successfully", groups = { Group.BVT,Group.Regression })
	public void VerifyCreatecustomer() {

		String requestJson = JsonUtils.getRequestPayload("//sample//Customer.json").toString();
		String responsejson = JsonUtils.getResponsePayload("//sample//customerResponse.json").toJSONString();
		// Response response =
		// request.body(requestJson).post(document_upload_endpoint).then().extract().response();
		Response response = request.body(requestJson).post(customer_endpoint).then().extract().response();

		test.log(LogStatus.INFO, requestWriter.toString());
		test.log(LogStatus.INFO,
				"Status code::" + response.getStatusCode() + "response body::" + response.prettyPrint());

		System.out.println(response.jsonPath().getString("id"));
		System.out.println("___________");

		CreateCustomerResponse createCustomerRes = response.getBody().as(CreateCustomerResponse.class);
		System.out.println("LMBOk: " + createCustomerRes.getJob());
		RestUtil.verifyStatusCode(response, 201);

		//
//		 assertNotEqualsDeep(actual, expected, message);
//		 Assert.assertEqualsDeep("","","");

	}
	
}
