package com.Boh.base;

import java.io.File;
import java.lang.reflect.Method;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.Boh.utils.ConfigManager;
import com.Boh.utils.Log;

public class BaseTest {
	public static ConfigManager config;
	final String PROPERTIES_FILE = "./src/main/resources/properties/Input.properties";
	public static ExtentReports extent;
	public ExtentTest test;

	public BaseTest() {
	}

	@BeforeSuite(alwaysRun = true)
	public final void mandatoryBeforeSuite(ITestContext context) {
		// config = ConfigManager.getInstance(PROPERTIES_FILE);
		String workingDir = System.getProperty("user.dir");
		System.out.println("working"+workingDir);
		extent = new ExtentReports(workingDir + "//target//TestExecutionResults.html", true);
		extent.loadConfig(new File(workingDir + "//src/main//resources//reportconfig.xml"));
		extent.addSystemInfo("Browser", "chrome");
	}

	@AfterSuite(alwaysRun = true)
	public final void mandatoryAfterSuite(ITestContext context) {
		Log.info("************ Suite execution completed *************");
				extent.flush();
		
	}

	@BeforeMethod(alwaysRun = true)
	public void mandatoryBeforeMethod(Method method) {
		test = extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()),
				method.getAnnotation(Test.class).description());
		test.log(LogStatus.INFO,
				"Started Test :: " + method.getName() + " :: " + method.getAnnotation(Test.class).description());
		Log.info("Started test case " + method.getName());
	}

	@AfterMethod(alwaysRun = true)
	public void mandatoryAfterMethod(ITestResult result, Method method) {
		if (result.getStatus() == ITestResult.FAILURE) {
			test.log(LogStatus.FAIL, "TEST CASE IS FAILED"); // to add name in extent report
			test.log(LogStatus.FAIL, "TEST CASE IS FAILED WITH REASON " + result.getThrowable()); // to add
																									// error/exception
																									// in
		} else if (result.getStatus() == ITestResult.SKIP) {
			test.log(LogStatus.SKIP, "TEST CASE IS SKIPPED ");
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(LogStatus.PASS, "TEST CASE IS PASSED");

		}
		Log.info("Finished test case " + method.getName());
		test.log(LogStatus.INFO, "Finished Test :: " + method.getName() + " :: " + result.getMethod().getDescription());
		extent.endTest(test);
	}

	@BeforeClass(alwaysRun = true)
	public void mandatoryBeforeClass() {
		Log.startTestCase(this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void mandatoryAfterClass() {
		Log.endTestCase(this.getClass().getName());
	}

	public void logData(String logStatus, String logData) {
		test.log(LogStatus.INFO, logData);
	}

}
