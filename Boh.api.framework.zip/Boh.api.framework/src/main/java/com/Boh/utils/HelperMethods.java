package com.Boh.utils;

import io.restassured.response.Response;

import static org.testng.Assert.assertEquals;

public class HelperMethods {
    /*
    Verify the http response status returned. Check Status Code is 200?
    We can use Rest Assured library's response's getStatusCode method
    */
    public static void checkStatusIs200(Response res) {
        assertEquals(200, res.getStatusCode(), "Status Check Failed! Expected 200. Actual is " + res.getStatusCode());
    }

    /*
    verifies the status code in response
    */
    public static void verifyStatusCode(Response res, int statusCode) {
        assertEquals(statusCode, res.getStatusCode(), "Status code is not matched. Expected: " + statusCode + " Actual is: " + res.getStatusCode());
    }


    /*
   verifies the status code 400 in response
   */
    public static void verifyStatusCode400(Response res) {
        assertEquals(400, res.getStatusCode(), "Status code is not matched. Expected: 400. Actual is: " + res.getStatusCode());
    }

    /*
  verifies the status code 500 in response
  */
    public static void verifyStatusCode500(Response res) {
        assertEquals(500, res.getStatusCode(), "Status code is not matched. Expected: 500. Actual is: " + res.getStatusCode());
    }

    /*
  verifies the status code 404 in response
  */
    public static void verifyStatusCode404(Response res) {
        assertEquals(404, res.getStatusCode(), "Status code is not matched. Expected: 404. Actual is: " + res.getStatusCode());
    }

    /*
  verifies the status code 405 in response
  */
    public static void verifyStatusCode405(Response res) {
        assertEquals(405, res.getStatusCode(), "Status code is not matched. Expected: 405. Actual is: " + res.getStatusCode());
    }

    /*
 verifies the status code 415 in response
 */
    public static void verifyStatusCode415(Response res) {
        assertEquals(415, res.getStatusCode(), "Status code is not matched. Expected: 415. Actual is: " + res.getStatusCode());
    }

    /*
verifies the status code 201 in response
*/
    public static void verifyStatusCode201(Response res) {
        assertEquals(201, res.getStatusCode(), "Status code is not matched. Expected: 201. Actual is: " + res.getStatusCode());
    }

}