package com.Boh.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

	private DateUtils() {

	}

	/**
	 * Returns the current time in given format
	 *
	 * @return Current Time as String in a given format
	 */

	public static String getCurrentTime(String format) {
		DateFormat df = new SimpleDateFormat(format);
		Date today = Calendar.getInstance().getTime();
		return df.format(today);
	}

	public static String getTomorrowDate(String format) {
		DateFormat df = new SimpleDateFormat(format);
		Date today = Calendar.getInstance().getTime();
		return df.format(today);
	}

}
