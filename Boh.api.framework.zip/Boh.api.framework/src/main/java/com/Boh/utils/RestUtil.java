package com.Boh.utils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyData;

import static io.restassured.RestAssured.*;

import java.util.Iterator;
import java.util.List;

import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class RestUtil {
	// Global Setup Variables
	public static String path; // Rest request path

	/*
	 *** Sets Base URI*** Before starting the test, we should set the
	 * RestAssured.baseURI
	 */
	public static void setBaseURI(String baseURI) {
		RestAssured.baseURI = baseURI;
	}

	/*
	 *** Sets base path*** Before starting the test, we should set the
	 * RestAssured.basePath
	 */
	public static void setBasePath(String basePathTerm) {
		RestAssured.basePath = basePathTerm;
	}

	/*
	 *** Reset Base URI (after test)*** After the test, we should reset the
	 * RestAssured.baseURI
	 */
	public static void resetBaseURI() {
		RestAssured.baseURI = null;
	}

	/*
	 *** Reset base path (after test)*** After the test, we should reset the
	 * RestAssured.basePath
	 */
	public static void resetBasePath() {
		RestAssured.basePath = null;
	}

	/*
	 *** Sets ContentType*** We should set content type as JSON or XML before starting
	 * the test
	 */
	public static void setContentType(ContentType Type) {
		given().contentType(Type);
	}

	/*
	 *** search query path of first example*** It is equal to
	 * "barack obama/videos.json?num_of_videos=4"
	 */
	public static void createSearchQueryPath(String searchTerm, String jsonPathTerm, String param, String paramValue) {
		path = searchTerm + "/" + jsonPathTerm + "?" + param + "=" + paramValue;
	}

	/*
	 *** Returns response*** We send "path" as a parameter to the Rest Assured'a "get"
	 * method and "get" method returns response of API
	 */
	public static Response getResponse() {
		// System.out.print("path: " + path +"\n");
		return get(path);
	}

	/*
	 *** Returns JsonPath object*** First convert the API's response to String type
	 * with "asString()" method. Then, send this String formatted json response to
	 * the JsonPath class and return the JsonPath
	 */
	public static JsonPath getJsonPath(Response res) {
		String json = res.asString();
		// System.out.print("returned json: " + json +"\n");
		return new JsonPath(json);
	}

	/*
	 * Verifies the status code in the response
	 */
	public static void verifyStatusCode(Response res, int statusCode) {
		Assert.assertEquals(res.getStatusCode(), statusCode,
				"Status code is not matched. Expected " + statusCode + " Actual status code is " + res.getStatusCode());
	}

	/*
	 * Verifies the content type in response
	 */
	public static void verifyResponseContentType(Response res, String contentType) {
		Assert.assertEquals(res.getContentType(), contentType, "Response content-type is not matched. Expected "
				+ contentType + " Actual content-type is " + res.getContentType());
	}

	/*
	 * Verifies the response contains the keys in it
	 */
	public static void verifyResponseContainsKeys(Response response, List<String> list) {
		SoftAssert sf = new SoftAssert();
		ResponseBodyData responseData = response.getBody();
		Iterator<String> li = list.iterator();
		String item;
		while (li.hasNext()) {
			item = li.next();
			sf.assertTrue(responseData.asString().contains(item), "Response doesn't contain :: " + item + " in response");
		}
		sf.assertAll();
	}
}