package com.Boh.utils;

import java.util.Random;

public class RandomGenerator {

	/**
	 * This method generates random string
	 * 
	 * @return
	 */
	public static String randomString(int length) {
		Random r = new Random(); // perhaps make it a class variable so you don't make a new one every time
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			char c = (char) (r.nextInt((int) (Character.MAX_VALUE)));
			sb.append(c);
		}
		return sb.toString();
	}

	/**
	 * This method generates random numbers
	 * 
	 * @return int
	 */
	public static int getRandomNumber() {
		int rNumber = 0;
		rNumber = (int) ((Math.random() * 9000000) + 1000000);
		Log.info("Random number generated is : "+rNumber);
		return rNumber;
	}
	
	/**
	 * 
	 * @param length
	 * @return
	 */
	public static String getRandomNumber(int length) {
		Random r = new Random();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			int n = r.nextInt(9);
			int c = (int) (n<1?1:n);
			sb.append(c);
		}
		return sb.toString();
	}
}
