package Boh.microservices.businessobjects.requestObjects.Sample;


import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Data
public class CreateCustomerRequest {
	private String id;
	private String name;
 	private String job;
 	private String Role;
 	private String createdAt;
	

}
